from itemadapter import ItemAdapter

class BookScraperPipeline:
    def process_item(self, item, spider):
        adapter = ItemAdapter(item)

        # Strip whitespace from title
        if adapter.get('title'):
            adapter['title'] = adapter['title'].strip()

        # Clean price
        if adapter.get('price'):
            price = adapter['price'].replace('£', '').strip()
            try:
                adapter['price'] = float(price)
            except ValueError:
                adapter['price'] = 0.0

        # Clean availability
        if adapter.get('availability'):
            adapter['availability'] = ''.join(adapter['availability']).strip()

        return item
