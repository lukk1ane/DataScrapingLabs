import scrapy
from webscrapy.items import BookItem


# run scrapy crawl books to get the sorted and stripped version 
# run scrapy crawl books -O books.csv and scrapy crawl books -O books.json to get the unsorted and unstripped version
class BooksSpider(scrapy.Spider):
    name = "books"
    allowed_domains = ["books.toscrape.com"]
    start_urls = ["https://books.toscrape.com/"]
    current_page = 1  
    max = 3  # maximum pages to scrape

    def parse(self, response):
        books = response.css("article.product_pod")
        for book in books:
            item = BookItem()
            item["title"] = book.css("h3 a::attr(title)").get()
            item["price"] = book.css(".price_color::text").get()
            availability = book.css(".availability::text").getall()
            availability = ''.join(availability).strip()

            if "In stock" in availability:
                item["availability"] = "In stock"
            else:
                item["availability"] = "not available"


            item["rating"] = book.css("p.star-rating").attrib["class"].split()[-1]
            yield item

        if self.current_page < self.max:
            next_page = response.css("li.next a::attr(href)").get()
            if next_page:
                self.current_page += 1
                yield response.follow(next_page, callback=self.parse)
