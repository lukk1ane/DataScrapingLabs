# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter

import csv, json


# run scrapy crawl books to get the sorted and stripped version 

class BookPipeline:
    def __init__(self):
        self.items = []

    def process_item(self, item, spider):
        # strip extra whitespace from product names
        item["title"] = item["title"].strip()

        # remove the currency sign
        price_str = item["price"].replace("£", "").strip()
        try:
            item["price"] = float(price_str)
        except ValueError:
            item["price"] = 0.0  

        self.items.append(item)
        return item  

    def close_spider(self, spider):
        # sort prices in ascending order
        self.items.sort(key=lambda x: x["price"])

        # save in json
        with open("books_sorted.json", "w", encoding="utf-8") as f:
            json.dump([dict(i) for i in self.items], f, ensure_ascii=False, indent=2)

        # save in csv
        with open("books_sorted.csv", "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["title", "price", "availability", "rating"])
            writer.writeheader()
            writer.writerows(self.items)
