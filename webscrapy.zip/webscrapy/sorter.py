import json
import csv
def sort_json():
    with open("webscrapy/data.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    sorted_data = sorted(data, key=lambda x: x['price'])
    with open("webscrapy/data.json", "w", encoding="utf-8") as f:
        json.dump(sorted_data, f, indent=2, ensure_ascii=False)
def sort_csv():
    with open('webscrapy/data.csv', newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        data = list(reader)

    # Sort by a column, e.g., "price" (convert to float if needed)
    sorted_data = sorted(data, key=lambda x: float(x['price']))

    # Write to a new sorted file
    with open('webscrapy/data.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=reader.fieldnames)
        writer.writeheader()
        writer.writerows(sorted_data)
sort_json()
sort_csv()