import scrapy
import json

class BooksSpider(scrapy.Spider):
    name = "books"
    allowed_domains = ["books.toscrape.com"]
    start_urls = ["https://books.toscrape.com/"]

    def parse(self, response):
        ol = response.css('ol[class="row"] li')
        for li in ol:
            title = li.css('h3 a::attr(title)').get().strip()
            price = li.css('p.price_color::text').get().replace("£", "")
            yield {
                "title": title,
                "price": price
            }
        next_page = response.css('li[class="next"] a').attrib['href']
        if next_page is not None:
            yield response.follow(next_page,callback=self.parse)

