import csv
import time
import random
import itertools
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

# --- User-Agent Rotation ---
user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Safari/605.1.15",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36"
]
# task1 user agent rotations
user_agent_cycle = itertools.cycle(user_agents)

session = requests.Session()
# task 6
session.headers.update({
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Referer": "https://google.com"
})


# stask2 mart delays
def smart_delay(min_sec, max_sec):
    time.sleep(random.uniform(min_sec, max_sec))

def retry_request(url, retries=3):
    delay = 1
    for attempt in range(retries):
        try:
            session.headers["User-Agent"] = next(user_agent_cycle)
            smart_delay(1, 3)
            response = session.get(url, timeout=10)
            response.raise_for_status()
            return BeautifulSoup(response.content, "html.parser")
        except requests.RequestException as e:
            print(f"[Retry {attempt+1}] Error fetching {url}: {e}")
            time.sleep(delay)
            # task 5
            delay *= 2  # exponential backoff
    return BeautifulSoup("", "html.parser")

def getPage(url):
    return retry_request(url)

def nextPage(url):
    soup = getPage(url)
    li = soup.find("li", class_="next")
    if li:
        return li.find("a").get("href")
    return None

def getBooks(soup):
    try:
        bookInfo = soup.find("div", class_="product_main")
        title = bookInfo.select_one('h1').get_text(strip=True)
        price = bookInfo.find("p", class_="price_color").get_text(strip=True)
        description = soup.find("div", id="product_description").find_next_sibling("p").get_text(strip=True)
        availability = soup.select('table > tr')[4].find("td").get_text(strip=True)

        return {
            "title": title,
            "price": price,
            "availability": availability,
            "description": description,
            "category": None,
            "star_rating": None
        }
    except Exception as e:
        print(f"[ERROR] Failed to parse book details: {e}")
        return None

def scrapBooks(url, base_url):
    soup = getPage(url)
    books = []
    categories_seen = set()
    ul = soup.select("ol[class='row'] > li")
    filtered = []

    for li in ul:
        p = li.find("p", class_="star-rating")
        if p:
            ratings = p.get("class")
            if "Four" in ratings or "Five" in ratings:
                filtered.append(li)

    for li in filtered:
        href = li.find("a").get("href")
        if not href.startswith('catalogue/'):
            href = 'catalogue/' + href
        book_url = urljoin(base_url, href)

        smart_delay(3, 6)  # simulate reading delay
        print(book_url)
        pageSoup = getPage(book_url)
        book = getBooks(pageSoup)

        if book:
            breadcrumb = pageSoup.find("ul", class_="breadcrumb")
            try:
                category = breadcrumb.find_all("li")[2].get_text(strip=True)
            except:
                category = "Unknown"

            rating = li.find("p", class_="star-rating").get("class")
            star_rating = 5 if "Five" in rating else 4

            if len(categories_seen) < 4:
                if category in categories_seen:
                    continue
                categories_seen.add(category)

            book["category"] = category
            book["star_rating"] = star_rating
            books.append(book)
    return books

def scrapper(start_url):
    data = []
    newurl = start_url

    while len(data) < 20:
        print(f"Scraping: {newurl}")
        new_books = scrapBooks(newurl, start_url)
        data.extend(new_books)
        if len(data) >= 20:
            break
        href = nextPage(newurl)
        if not href:
            break
        if not href.startswith('catalogue/'):
            href = 'catalogue/' + href
        newurl = urljoin(start_url, href)

    return data[:20]

def save_to_csv(books, filename="books.csv"):
    keys = ["title", "price", "availability", "star_rating", "description", "category"]
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for book in books:
            if all(book.get(key) for key in keys):  # simple data validation
                writer.writerow(book)

if __name__ == '__main__':
    books = scrapper("https://books.toscrape.com/")
    print(f"Scraped {len(books)} books")
    save_to_csv(books)
