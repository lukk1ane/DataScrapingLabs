import requests
from bs4 import BeautifulSoup
import time
import re
import json

def scrape_csrf_protected_products():
    session = requests.Session()
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    session.headers.update(headers)
    
    try:
        # Target the CSRF protected login page
        login_url = "https://www.scrapingcourse.com/login/csrf"
        response = session.get(login_url)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Find the login form
        login_form = soup.find('form')
        if not login_form:
            print("No login form found")
            return
        
        # Get form action
        form_action = login_form.get('action', '')
        if form_action.startswith('/'):
            form_action = "https://www.scrapingcourse.com" + form_action
        elif not form_action.startswith('http'):
            form_action = login_url
        
        # Extract all hidden inputs including CSRF token
        hidden_inputs = login_form.find_all('input', type='hidden')
        form_data = {}
        csrf_token = None
        
        for inp in hidden_inputs:
            name = inp.get('name')
            value = inp.get('value', '')
            if name:
                form_data[name] = value
                # Look for CSRF token fields (common names)
                if any(csrf_name in name.lower() for csrf_name in ['csrf', 'token', '_token', 'authenticity_token', 'csrfmiddlewaretoken']):
                    csrf_token = value
                    print(f"Found CSRF token field: {name} = {value}")
        
        # If no explicit CSRF field found, look for meta tags
        if not csrf_token:
            csrf_meta = soup.find('meta', attrs={'name': lambda x: x and 'csrf' in x.lower()})
            if not csrf_meta:
                csrf_meta = soup.find('meta', attrs={'name': 'csrf-token'}) or soup.find('meta', attrs={'name': '_token'})
            if csrf_meta:
                csrf_token = csrf_meta.get('content')
                form_data['csrf_token'] = csrf_token
                print(f"Found CSRF token in meta tag: {csrf_token}")
        
        # Find username and password field names
        username_field = "username"
        password_field = "password"
        
        for input_tag in login_form.find_all('input'):
            input_type = input_tag.get('type', '').lower()
            input_name = input_tag.get('name', '')
            
            if input_name:
                input_name_lower = input_name.lower()
                if input_type in ['text', 'email'] or any(field in input_name_lower for field in ['username', 'email', 'user', 'login']):
                    username_field = input_name
                elif input_type == 'password' or any(field in input_name_lower for field in ['password', 'pass', 'pwd']):
                    password_field = input_name
        
        print(f"Username field: {username_field}, Password field: {password_field}")
        
        # Try different credential combinations
        credentials_to_try = [
            ('admin', 'admin'),
            ('demo', 'demo'),
            ('test', 'test'),
            ('user', 'password'),
            ('guest', 'guest')
        ]
        
        login_successful = False
        login_response = None
        
        for username, password in credentials_to_try:
            # Prepare form data with credentials
            current_form_data = form_data.copy()
            current_form_data[username_field] = username
            current_form_data[password_field] = password
            
            print(f"Trying credentials: {username}/{password}")
            
            # Submit login form
            login_response = session.post(form_action, data=current_form_data, allow_redirects=True)
            login_response.raise_for_status()
            
            # Check if login was successful
            response_text = login_response.text.lower()
            login_success_indicators = ['dashboard', 'welcome', 'logout', 'profile', 'account', 'member', 'success']
            login_failed_indicators = ['invalid', 'error', 'failed', 'incorrect', 'try again', 'wrong']
            
            success = any(indicator in response_text for indicator in login_success_indicators)
            failed = any(indicator in response_text for indicator in login_failed_indicators)
            
            # Additional check: if we're no longer on a login page, it might be successful
            if not failed and ('login' not in response_text or 'logout' in response_text):
                success = True
            
            if success and not failed:
                print(f"Login successful with {username}/{password}")
                login_successful = True
                break
            elif failed:
                print(f"Login failed with {username}/{password}")
            else:
                print(f"Login status unclear with {username}/{password}")
        
        if not login_successful:
            print("Could not login with any credentials")
            return None
        
        # Look for product pages after successful login
        current_soup = BeautifulSoup(login_response.content, 'html.parser')
        protected_links = []
        
        for link in current_soup.find_all('a', href=True):
            href = link['href']
            link_text = link.get_text(strip=True).lower()
            
            # Convert relative URLs to absolute
            if href.startswith('/'):
                href = "https://www.scrapingcourse.com" + href
            elif not href.startswith('http'):
                href = "https://www.scrapingcourse.com/" + href
            
            # Look for product-related links
            keywords = ['product', 'shop', 'store', 'item', 'catalog', 'protected', 'dashboard', 'member', 'ecommerce']
            if any(keyword in href.lower() or keyword in link_text for keyword in keywords):
                protected_links.append((href, link_text))
        
        # List of potential product URLs to try
        products_urls = [
            "https://www.scrapingcourse.com/ecommerce",
            "https://www.scrapingcourse.com/products",
            "https://www.scrapingcourse.com/protected-products", 
            "https://www.scrapingcourse.com/shop",
            "https://www.scrapingcourse.com/items",
            "https://www.scrapingcourse.com/dashboard",
            "https://www.scrapingcourse.com/member-area",
            "https://www.scrapingcourse.com/secure",
            "https://www.scrapingcourse.com/login/csrf/products",
            "https://www.scrapingcourse.com/csrf/products"
        ]
        
        # Add discovered links
        for href, _ in protected_links:
            if href not in products_urls:
                products_urls.append(href)
        
        # Try to find the products page
        products_response = None
        products_url = None
        
        for url in products_urls:
            try:
                print(f"Trying products URL: {url}")
                products_response = session.get(url)
                if products_response.status_code == 200:
                    content = products_response.text.lower()
                    product_indicators = ['product', 'price', 'buy', 'item', 'cart', 'add to cart', 'shop', '$']
                    if any(keyword in content for keyword in product_indicators):
                        products_url = url
                        print(f"Found products page: {url}")
                        break
            except requests.RequestException as e:
                print(f"Error accessing {url}: {e}")
                continue
        
        if not products_response or products_response.status_code != 200:
            print("Could not find or access products page")
            return None
        
        # Parse products from the page
        products_soup = BeautifulSoup(products_response.content, 'html.parser')
        
        # Try various selectors to find products
        product_selectors = [
            '.product', '.item', '.product-item', '.card',
            '[class*="product"]', '[class*="item"]', 'article',
            '.listing', '.product-card', '.shop-item'
        ]
        
        products = []
        used_selector = None
        
        for selector in product_selectors:
            found_products = products_soup.select(selector)
            if found_products:
                products = found_products
                used_selector = selector
                print(f"Found {len(products)} products using selector: {selector}")
                break
        
        # Fallback: look for divs with product-related classes
        if not products:
            potential_products = products_soup.find_all(['div', 'article', 'section'], 
                                                        class_=lambda x: x and any(keyword in x.lower() 
                                                        for keyword in ['product', 'item', 'card']))
            if potential_products:
                products = potential_products
                used_selector = "class containing product/item/card"
                print(f"Found {len(products)} products using fallback method")
        
        if not products:
            print("No products found on the page")
            return None
        
        # Extract product information
        extracted_products = []
        
        for i, product in enumerate(products):
            product_data = {}
            
            # Extract title
            title = None
            for selector in [
                'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
                '.title', '.name', '.product-title', '.product-name',
                '[class*="title"]', '[class*="name"]',
                'a[href*="product"]'
            ]:
                title_element = product.select_one(selector)
                if title_element:
                    title = title_element.get_text(strip=True)
                    if title:
                        break
            
            # Extract price
            price = None
            for selector in [
                '.price', '.cost', '.amount',
                '[class*="price"]', '[class*="cost"]', '[class*="amount"]',
                'span:contains("$")', 'span:contains("€")', 'span:contains("£")'
            ]:
                price_element = product.select_one(selector)
                if price_element:
                    price_text = price_element.get_text(strip=True)
                    if any(symbol in price_text for symbol in ['$', '€', '£', '¥']) or \
                       re.search(r'\d+\.\d{2}', price_text):
                        price = price_text
                        break
            
            # Fallback price extraction using regex
            if not price:
                all_text = product.get_text()
                price_pattern = r'[\$€£¥]\s*\d+(?:[.,]\d{2})?|\d+(?:[.,]\d{2})?\s*[\$€£¥]'
                price_match = re.search(price_pattern, all_text)
                if price_match:
                    price = price_match.group()
            
            # Extract description
            description = None
            for selector in [
                '.description', '.desc', '.summary',
                '[class*="description"]', '[class*="desc"]',
                'p'
            ]:
                desc_element = product.select_one(selector)
                if desc_element:
                    desc_text = desc_element.get_text(strip=True)
                    if len(desc_text) > 20 and desc_text != title:
                        description = desc_text[:200] + "..." if len(desc_text) > 200 else desc_text
                        break
            
            # Extract image URL
            img_element = product.select_one('img')
            image_url = None
            if img_element:
                image_url = img_element.get('src') or img_element.get('data-src')
                if image_url and image_url.startswith('/'):
                    image_url = "https://www.scrapingcourse.com" + image_url
            
            # Extract product URL
            link_element = product.select_one('a[href]')
            product_url = None
            if link_element:
                product_url = link_element.get('href')
                if product_url and product_url.startswith('/'):
                    product_url = "https://www.scrapingcourse.com" + product_url
            
            # Only add products that have at least some information
            if title or price or description:
                product_data = {
                    'title': title or 'N/A',
                    'price': price or 'N/A',
                    'description': description or 'N/A',
                    'image_url': image_url or 'N/A',
                    'product_url': product_url or 'N/A'
                }
                extracted_products.append(product_data)
                print(f"Extracted product {i+1}: {title}")
        
        # Save results to JSON file
        if extracted_products:
            try:
                with open("scraped_csrf_products.json", 'w', encoding='utf-8') as f:
                    json.dump(extracted_products, f, indent=2, ensure_ascii=False)
                print(f"Saved {len(extracted_products)} products to scraped_csrf_products.json")
            except Exception as e:
                print(f"Error saving to file: {e}")
        
        return extracted_products
        
    except requests.RequestException as e:
        print(f"Request error: {e}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None

def scrape_login_protected_products():
    """Original function for regular login without CSRF"""
    session = requests.Session()
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    session.headers.update(headers)
    
    try:
        login_url = "https://www.scrapingcourse.com/login"
        response = session.get(login_url)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        login_form = soup.find('form')
        if not login_form:
            return
        
        form_action = login_form.get('action', '')
        if form_action.startswith('/'):
            form_action = "https://www.scrapingcourse.com" + form_action
        elif not form_action.startswith('http'):
            form_action = login_url
        
        hidden_inputs = login_form.find_all('input', type='hidden')
        form_data = {inp.get('name'): inp.get('value', '') for inp in hidden_inputs if inp.get('name')}
        
        username_field = "Username"
        password_field = "Password"
        
        for input_tag in login_form.find_all('input'):
            input_type = input_tag.get('type', '').lower()
            input_name = input_tag.get('name', '').lower()
            if input_type in ['text', 'email'] or any(field in input_name for field in ['username', 'email', 'user', 'login']):
                username_field = input_tag.get('name')
            elif input_type == 'password' or any(field in input_name for field in ['password', 'pass', 'pwd']):
                password_field = input_tag.get('name')
        
        form_data[username_field] = 'admin'
        form_data[password_field] = 'admin'
        
        login_response = session.post(form_action, data=form_data, allow_redirects=True)
        login_response.raise_for_status()
        
        response_text = login_response.text.lower()
        login_success_indicators = ['dashboard', 'welcome', 'logout', 'profile', 'account', 'member']
        login_failed_indicators = ['invalid', 'error', 'failed', 'incorrect', 'try again']
        
        success = any(indicator in response_text for indicator in login_success_indicators)
        failed = any(indicator in response_text for indicator in login_failed_indicators)
        
        if failed or ('login' in response_text and 'logout' not in response_text):
            credentials_to_try = [
                ('demo', 'demo'),
                ('test', 'test'),
                ('user', 'password'),
                ('guest', 'guest')
            ]
            for username, password in credentials_to_try:
                form_data[username_field] = username
                form_data[password_field] = password
                login_response = session.post(form_action, data=form_data, allow_redirects=True)
                response_text = login_response.text.lower()
                success = any(indicator in response_text for indicator in login_success_indicators)
                failed = any(indicator in response_text for indicator in login_failed_indicators)
                if success or (not failed and 'login' not in response_text):
                    break
        
        current_soup = BeautifulSoup(login_response.content, 'html.parser')
        protected_links = []
        for link in current_soup.find_all('a', href=True):
            href = link['href']
            link_text = link.get_text(strip=True).lower()
            if href.startswith('/'):
                href = "https://www.scrapingcourse.com" + href
            elif not href.startswith('http'):
                href = "https://www.scrapingcourse.com/" + href
            keywords = ['product', 'shop', 'store', 'item', 'catalog', 'protected', 'dashboard', 'member', 'ecommerce']
            if any(keyword in href.lower() or keyword in link_text for keyword in keywords):
                protected_links.append((href, link_text))
        
        products_urls = [
            "https://www.scrapingcourse.com/ecommerce",
            "https://www.scrapingcourse.com/products",
            "https://www.scrapingcourse.com/protected-products", 
            "https://www.scrapingcourse.com/shop",
            "https://www.scrapingcourse.com/items",
            "https://www.scrapingcourse.com/dashboard",
            "https://www.scrapingcourse.com/member-area",
            "https://www.scrapingcourse.com/secure"
        ]
        
        for href, _ in protected_links:
            if href not in products_urls:
                products_urls.append(href)
        
        products_response = None
        products_url = None
        
        for url in products_urls:
            try:
                products_response = session.get(url)
                if products_response.status_code == 200:
                    content = products_response.text.lower()
                    product_indicators = ['product', 'price', 'buy', 'item', 'cart', 'add to cart', 'shop', '$']
                    if any(keyword in content for keyword in product_indicators):
                        products_url = url
                        break
            except requests.RequestException:
                continue
        
        if not products_response or products_response.status_code != 200:
            return
        
        products_soup = BeautifulSoup(products_response.content, 'html.parser')
        product_selectors = [
            '.product', '.item', '.product-item', '.card',
            '[class*="product"]', '[class*="item"]', 'article',
            '.listing', '.product-card'
        ]
        
        products = []
        used_selector = None
        
        for selector in product_selectors:
            found_products = products_soup.select(selector)
            if found_products:
                products = found_products
                used_selector = selector
                break
        
        if not products:
            potential_products = products_soup.find_all(['div', 'article', 'section'], 
                                                        class_=lambda x: x and any(keyword in x.lower() 
                                                        for keyword in ['product', 'item', 'card']))
            if potential_products:
                products = potential_products
                used_selector = "class containing product/item/card"
        
        if not products:
            return
        
        extracted_products = []
        
        for product in products:
            product_data = {}
            title = None
            for selector in [
                'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
                '.title', '.name', '.product-title', '.product-name',
                '[class*="title"]', '[class*="name"]',
                'a[href*="product"]'
            ]:
                title_element = product.select_one(selector)
                if title_element:
                    title = title_element.get_text(strip=True)
                    if title:
                        break
            
            price = None
            for selector in [
                '.price', '.cost', '.amount',
                '[class*="price"]', '[class*="cost"]', '[class*="amount"]',
                'span:contains("$")', 'span:contains("€")', 'span:contains("£")'
            ]:
                price_element = product.select_one(selector)
                if price_element:
                    price_text = price_element.get_text(strip=True)
                    if any(symbol in price_text for symbol in ['$', '€', '£', '¥']) or \
                       re.search(r'\d+\.\d{2}', price_text):
                        price = price_text
                        break
            
            if not price:
                all_text = product.get_text()
                price_pattern = r'[\$€£¥]\s*\d+(?:[.,]\d{2})?|\d+(?:[.,]\d{2})?\s*[\$€£¥]'
                price_match = re.search(price_pattern, all_text)
                if price_match:
                    price = price_match.group()
            
            description = None
            for selector in [
                '.description', '.desc', '.summary',
                '[class*="description"]', '[class*="desc"]',
                'p'
            ]:
                desc_element = product.select_one(selector)
                if desc_element:
                    desc_text = desc_element.get_text(strip=True)
                    if len(desc_text) > 20 and desc_text != title:
                        description = desc_text[:200] + "..." if len(desc_text) > 200 else desc_text
                        break
            
            img_element = product.select_one('img')
            image_url = img_element.get('src') or img_element.get('data-src') if img_element else None
            if image_url and image_url.startswith('/'):
                image_url = "https://www.scrapingcourse.com" + image_url
            
            link_element = product.select_one('a[href]')
            product_url = link_element.get('href') if link_element else None
            if product_url and product_url.startswith('/'):
                product_url = "https://www.scrapingcourse.com" + product_url
            
            if title or price or description:
                product_data = {
                    'title': title or 'N/A',
                    'price': price or 'N/A',
                    'description': description or 'N/A',
                    'image_url': image_url or 'N/A',
                    'product_url': product_url or 'N/A'
                }
                extracted_products.append(product_data)
        
        if extracted_products:
            try:
                with open("scraped_products.json", 'w', encoding='utf-8') as f:
                    json.dump(extracted_products, f, indent=2, ensure_ascii=False)
            except Exception:
                pass
        
        return extracted_products
        
    except requests.RequestException:
        return None
    except Exception:
        return None

if __name__ == "__main__":
    print("=== Scraping CSRF Protected Products ===")
    csrf_results = scrape_csrf_protected_products()
    if csrf_results:
        print(f"Extracted {len(csrf_results)} products from CSRF protected site")
        for i, product in enumerate(csrf_results[:3], 1):  # Show first 3 products
            print(f"\nProduct {i}:")
            print(f"  Title: {product['title']}")
            print(f"  Price: {product['price']}")
            print(f"  Description: {product['description'][:100]}..." if len(product['description']) > 100 else f"  Description: {product['description']}")
    else:
        print("No products were extracted from CSRF protected site")
    
    print("\n" + "="*50)
    print("=== Scraping Regular Login Protected Products ===")
    regular_results = scrape_login_protected_products()
    if regular_results:
        print(f"Extracted {len(regular_results)} products from regular login protected site")
        for i, product in enumerate(regular_results[:3], 1):  # Show first 3 products
            print(f"\nProduct {i}:")
            print(f"  Title: {product['title']}")
            print(f"  Price: {product['price']}")
            print(f"  Description: {product['description'][:100]}..." if len(product['description']) > 100 else f"  Description: {product['description']}")
    else:
        print("No products were extracted from regular login protected site")