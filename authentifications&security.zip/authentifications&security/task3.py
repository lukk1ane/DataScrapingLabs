import requests
from bs4 import BeautifulSoup
import pickle

LOGIN_GET_URL = 'https://www.scrapingcourse.com/login/csrf'
LOGIN_POST_URL = 'https://www.scrapingcourse.com/login'
PRODUCTS_URL = 'https://www.scrapingcourse.com/products'
COOKIES_FILE = 'cookies_task3.pkl'

session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'
})

response = session.get(LOGIN_GET_URL)
soup = BeautifulSoup(response.text, 'html.parser')
csrf_input = soup.find('input', {'name': '_token'})

if not csrf_input:
    print("CSRF token not found!")
    print(soup.prettify())
    exit()

csrf_token = csrf_input['value']

login_payload = {
    'email': 'admin@scrapingcourse.com',
    'password': 'password',
    '_token': csrf_token
}
login_response = session.post(LOGIN_POST_URL, data=login_payload)

print("\nCookies after login:")
for cookie in session.cookies:
    print(f"{cookie.name} = {cookie.value}")

response = session.get(PRODUCTS_URL)
print("\nAccess after login:", "Products" in response.text)

if 'session' in session.cookies:
    print("\nTampering with 'session' cookie...")
    session.cookies.set('session', 'tampered_session_value')

response = session.get(PRODUCTS_URL)
print("Access after tampering:", "Products" in response.text)

with open(COOKIES_FILE, 'wb') as f:
    pickle.dump(session.cookies, f)
print("\nCookies saved to:", COOKIES_FILE)

new_session = requests.Session()
new_session.headers.update(session.headers)
with open(COOKIES_FILE, 'rb') as f:
    new_session.cookies.update(pickle.load(f))

response = new_session.get(PRODUCTS_URL)
print("Access using loaded cookies:", "Products" in response.text)
