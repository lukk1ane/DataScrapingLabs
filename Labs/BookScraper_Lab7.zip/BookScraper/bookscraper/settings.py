BOT_NAME = 'bookscraper'
SPIDER_MODULES = ['bookscraper.spiders']
NEWSPIDER_MODULE = 'bookscraper.spiders'

ITEM_PIPELINES = {
    'bookscraper.pipelines.PricePipeline': 300,
    'bookscraper.pipelines.CsvJsonPipeline': 400,
}
