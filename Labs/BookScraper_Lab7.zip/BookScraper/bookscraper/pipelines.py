import csv
import json

class PricePipeline:
    def process_item(self, item, spider):
        item['title'] = item['title'].strip()
        item['price'] = float(item['price'].replace('£', ''))
        return item

class CsvJsonPipeline:
    def open_spider(self, spider):
        self.csv_file = open('books.csv', 'w', newline='')
        self.json_file = open('books.json', 'w')
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow(['Title', 'Price'])
        self.items = []

    def process_item(self, item, spider):
        self.csv_writer.writerow([item['title'], item['price']])
        self.items.append(item)
        return item

    def close_spider(self, spider):
        json.dump(self.items, self.json_file, indent=4)
        self.csv_file.close()
        self.json_file.close()
