import scrapy
from bookscraper.items import BookItem

class BooksSpider(scrapy.Spider):
    name = 'books'
    start_urls = ['https://books.toscrape.com/']

    def parse(self, response):
        self.logger.info(f"Scraping URL: {response.url}")

        # Verify page content
        self.logger.debug(f"Page content:\n{response.text[:500]}")  # Print first 500 characters of the page

        books = response.css('article.product_pod')

        if not books:
            self.logger.warning("No books found on the page. Check the selector.")
        else:
            self.logger.info(f"Found {len(books)} books on the page.")

        for book in books:
            title = book.css('h3 a::attr(title)').get()
            price = book.css('p.price_color::text').get()

            if title and price:
                item = BookItem()
                item['title'] = title.strip()
                item['price'] = price.strip()
                self.logger.info(f"Scraped item: {item}")
                yield item

        # Handle pagination
        next_page = response.css('li.next a::attr(href)').get()
        if next_page:
            self.logger.info(f"Following pagination to {next_page}")
            yield response.follow(next_page, self.parse)
        else:
            self.logger.info("No more pages to scrape.")
