import random
import csv
import time
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

BASE_URL = "https://books.toscrape.com/"
HEADERS_LIST = [
    {
        "User-Agent": ua,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9",
        "Referer": BASE_URL,
        "Accept-Language": "en-US,en;q=0.9"
    }
    for ua in [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
        "Mozilla/5.0 (X11; Linux x86_64)",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)",
        "Mozilla/5.0 (iPad; CPU OS 13_3 like Mac OS X)"
    ]
]

session = requests.Session()
scraped_books = []
seen_categories = set()

def get_soup(url, retries=3, delay=1):
    for attempt in range(retries):
        try:
            headers = random.choice(HEADERS_LIST)
            time.sleep(random.uniform(delay, delay + 2))
            response = session.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            return BeautifulSoup(response.text, "html.parser")
        except Exception as e:
            wait_time = 2 ** attempt
            print(f"[Retry] {e} (waiting {wait_time}s)")
            time.sleep(wait_time)
    return None

def get_star_rating(tag):
    classes = tag.get("class", [])
    rating_map = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
    for cls in classes:
        if cls in rating_map:
            return rating_map[cls]
    return 0

def scrape_category(category_url, category_name):
    page_url = category_url
    while page_url and len(scraped_books) < 20:
        soup = get_soup(page_url, delay=2)
        if not soup:
            break

        books = soup.select("article.product_pod")
        for book in books:
            if len(scraped_books) >= 20:
                return

            rating = get_star_rating(book.select_one(".star-rating"))
            if rating < 4:
                continue

            book_url = urljoin(category_url, book.h3.a["href"])
            book_soup = get_soup(book_url, delay=3)
            if not book_soup:
                continue

            title = book_soup.h1.text.strip()
            price = book_soup.select_one(".price_color").text.strip().replace("Â", "")
            availability = book_soup.select_one(".availability").text.strip()
            description_tag = book_soup.select_one("#product_description")
            description = description_tag.find_next_sibling("p").text.strip() if description_tag else "No description"
            description = description[:300]  # Limit to 300 chars

            scraped_books.append({
                "title": title,
                "price": price,
                "availability": availability,
                "star_rating": rating,
                "description": description,
                "category": category_name
            })
            seen_categories.add(category_name)

        next_link = soup.select_one("li.next > a")
        page_url = urljoin(page_url, next_link['href']) if next_link else None

def scrape():
    main_soup = get_soup(BASE_URL)
    if not main_soup:
        print("Failed to load base URL.")
        return

    categories = main_soup.select(".side_categories ul li ul li a")
    random.shuffle(categories)

    for category in categories:
        if len(scraped_books) >= 20 and len(seen_categories) >= 3:
            break
        category_name = category.text.strip()
        category_url = urljoin(BASE_URL, category['href'])
        print(f"Scraping category: {category_name}")
        scrape_category(category_url, category_name)

def save_to_csv(filename="filtered_books.csv"):
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["title", "price", "availability", "star_rating", "description", "category"])
        writer.writeheader()
        writer.writerows(scraped_books)


# Run the scraper
scrape()
save_to_csv()
