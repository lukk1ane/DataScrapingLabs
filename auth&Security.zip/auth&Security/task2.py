from bs4 import BeautifulSoup
import requests

if __name__ == '__main__':
    session = requests.session()

    url = "https://www.scrapingcourse.com/login/csrf"
    response = session.get(url)
    soup = BeautifulSoup(response.text,"html.parser")
    token = soup.find("input",{"name": "_token"})["value"]
    payload = {
        "_token": token,
        "email" : "admin@example.com",
        "password" : "password"
    }
    response = session.post(url,payload)
    soup = BeautifulSoup(response.text,"html.parser")
    info = soup.find_all("div",class_="product-info self-start text-left w-full")
    for i in range(len(info)):
        el = info[i]
        title = el.find("span",class_="product-name").text
        price = el.find("span",class_="product-price text-slate-600").text
        print(f'{i}-- Title: {title}, Price: {price}')