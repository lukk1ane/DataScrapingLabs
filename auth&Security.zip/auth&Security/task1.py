from bs4 import BeautifulSoup
import requests

if __name__ == '__main__':
    url = "https://www.scrapingcourse.com/login"
    payload = {
        "email" : "admin@example.com",
        "password" : "password"
    }
    response = requests.post(url,payload)
    soap = BeautifulSoup(response.text,"html.parser")
    info = soap.find_all("div",class_="product-info self-start text-left w-full")
    for i in range(len(info)):
        el = info[i]
        title = el.find("span",class_="product-name").text
        price = el.find("span",class_="product-price text-slate-600").text
        print(f'{i}-- Title: {title}, Price: {price}')