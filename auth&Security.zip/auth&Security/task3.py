from bs4 import BeautifulSoup
import requests
import pickle

def login_without_cookies(url):
    session = requests.session()
    response = session.get(url)
    soup = BeautifulSoup(response.text, "html.parser")
    token = soup.find("input", {"name": "_token"})["value"]

    payload = {
        "_token": token,
        "email": "admin@example.com",
        "password": "password"
    }

    response = session.post(url, payload)
    print("Cookies after login:")
    for cookie in session.cookies:
        print(f'cookieName: {cookie.name}, Value: {cookie.value}')
    with open("cookies.pkl", "wb") as f:
        pickle.dump(session.cookies, f)

    protected = session.get('https://www.scrapingcourse.com/dashboard')
    print("\nAccess with valid cookies:", protected.ok)
    for cookie in list(session.cookies):
        session.cookies.set(
            cookie.name,
            'invalid_' + cookie.name,
            domain=cookie.domain,
            path=cookie.path
        )

    invalid_access = session.get('https://www.scrapingcourse.com/dashboard')
    print("Access with tampered cookie:", invalid_access.status_code)
    # check if we can access protected page
    if "Hoodie" in invalid_access.text:
        print("Still authenticated.")
    else:
        print("not authenticated - can not visit protected page.")
    session.cookies.clear()
    session.close()

def login_with_cookies(url):
    new_session = requests.Session()
    with open("cookies.pkl", "rb") as f:
        new_session.cookies.update(pickle.load(f))

    # Use new_session to access authenticated pages
    response = new_session.get(url)
    print(response.status_code)
    if "Hoodie" in response.text:
        print("Still authenticated.")
    else:
        print("not authenticated - can not visit protected page.")

if __name__ == '__main__':
    url = "https://www.scrapingcourse.com/login/csrf"
    login_without_cookies(url)
    print("______________________________________")
    print("acess protected by saved cookies")
    login_with_cookies('https://www.scrapingcourse.com/dashboard')